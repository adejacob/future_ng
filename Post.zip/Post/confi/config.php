<?php 
define('ROOT_URL', 'http://localhost:8000/eBusiness/future nigeria/Post/');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'data');

?>