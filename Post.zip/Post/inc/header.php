<!DOCTYPE html>
<html>
<head>
	<title>Future Nigeria Blog</title>
	<link rel="stylesheet" type="text/css" href="https://bootswatch.com/3/cerulean/bootstrap.min.css">
	 <link href="img/ff.jpg" rel="icon">
</head>
<body>
	<?php include('navbar.php'); ?>