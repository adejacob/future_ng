
<link rel="stylesheet" type="text/css" href="inc/style.css">

<div class="header">
  <div id="future">
     <a href="index.html" ><img src="img/ff.jpg"></a>
  </div>
  <a href="#default" class="logo">Future Nigeria Blog</a>
  <div class="header-right">
    <a href="<?php echo ROOT_URL; ?>post.php">Home</a>
    <a href="<?php echo ROOT_URL; ?>addpost.php">Add Post</a>
  </div>
</div>